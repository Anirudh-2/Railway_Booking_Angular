export const environment = {
    ApiEndPoint: 'https://freeapi.miniprojectideas.com/api/TrainApp/'
};
